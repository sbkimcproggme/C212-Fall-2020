import java.awt.*;

public class Mondrian{
    int x, y;
    double scale;
    public Mondrian(int x, int y, double scale) {
        this.x = x;
        this.y = y;
        this.scale = scale;
    }
    private int scale(int size){

        return (int)(this.scale * size);
    }
    public void paint(Graphics g) {
        // Rectangles
        g.setColor(new Color(255, 55, 0));
        g.fillRect(x+100, y+0, scale(400), scale(400));
        g.setColor(new Color(65, 97, 198));
        g.fillRect(x+0, y+400, scale(100), scale(100));
        g.setColor(new Color(255, 228, 0));
        g.fillRect(x+470, y+440, scale(30), scale(60));

        // Lines
        g.setColor(new Color(0, 0, 0));
        for (int x=0; x<4; x++){
            int xind = 100;
            g.drawLine(x+scale(xind++),y+scale(0), scale(xind++),scale(500));
        }
        for (int x=0; x<4; x++){
            int yind = 400;
            g.drawLine(x+scale(0),y+scale(yind++), scale(500),scale(yind++));
        }
        for (int x=0; x<9; x++){
            int yind = 120;
            g.drawLine(x+scale(0),y+scale(yind++), scale(100),scale(yind++));
        }
        for (int x=0; x<4; x++){
            int xind = 470;
            int yind = 400;
            g.drawLine(x+scale(xind++),y+scale(yind++), scale(xind++),scale(500));
        }
        for (int x=0; x<4; x++){
            int xind = 470;
            int yind = 440;
            g.drawLine(x+scale(xind++),y+scale(yind++), scale(500),scale(yind++));
        }

        // Triangles
        g.setColor(new Color(255, 255, 255));
        g.fillPolygon(new Polygon(new int[] {x+scale(0), x+scale(0), x+scale(250)}, new int[] {y+scale(0), y+scale(125), y+scale(0)}, 3));
        g.fillPolygon(new Polygon(new int[] {x+scale(250), x+scale(500), x+scale(500)}, new int[] {y+scale(0), y+scale(125), y+scale(0)}, 3));
        g.fillPolygon(new Polygon(new int[] {x+scale(0), x+scale(0), x+scale(250)}, new int[] {y+scale(0), y+scale(125), y+scale(0)}, 3));
        g.fillPolygon(new Polygon(new int[] {x+scale(0), x+scale(0), x+scale(250)}, new int[] {y+scale(0), y+scale(125), y+scale(0)}, 3));

        // Lines Second stage
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(new Color(255, 255, 255));
        g2.setStroke(new BasicStroke(scale(40)));
        g2.drawLine(x+scale(0), y+scale(250), scale(250), scale(500));
        g2.setStroke(new BasicStroke(45));
        g2.drawLine(x+scale(500), y+scale(250), scale(200), scale(430));
        g2.setStroke(new BasicStroke(30));
        g2.drawLine(scale(450), y+scale(500), scale(350), scale(380));
        g2.setStroke(new BasicStroke(scale(15)));
        g2.drawLine(scale(500), y+scale(360), scale(450), scale(300));

        // Lines Second stage
        g.setColor(new Color(255, 255, 255));
        g.setFont(new Font("TIMES NEW ROMAN", Font.ITALIC, scale(20)));
        g.drawString("SB KIM influenced by Piet Mondrian ", scale(130), scale(250));
    }
}
